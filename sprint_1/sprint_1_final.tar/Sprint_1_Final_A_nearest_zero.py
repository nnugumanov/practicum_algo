from __future__ import unicode_literals, absolute_import, division, print_function

# ID посылки - 69666696

# From task description: "Номера домов (положительные числа) уникальны и не превосходят 10^9"
# We'll use 10^10 as INFINITY value. '-1' also could be used, but we'll had to add 'if' check
UNLIMITED_DISTANCE_VALUE = 10000000000

def nearest_zero(source: list) -> list:
    result = []
    current_distance = UNLIMITED_DISTANCE_VALUE

    def refine_previous_marks(start_pos: int) -> None:
        """
        Update distance values backwards, while newly calculated distance is less than previously calculated
         distance.
        :param start_pos:
        :return:
        """
        corrected_value = 1

        for j in range(start_pos):
            if result[start_pos - j - 1] > corrected_value:
                result[start_pos - j - 1] = corrected_value
            else:
                return

            corrected_value += 1

    for i in range(len(source)):
        if source[i] == 0:
            current_distance = 0
            refine_previous_marks(i)

        result.append(current_distance)
        current_distance += 1

    return result

if __name__ == "__main__":
    street_length = int(input())
    street = [int(x) for x in input().split()]

    print(*nearest_zero(street))
