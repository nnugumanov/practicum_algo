
# ID посылки - 69673685

if __name__ == "__main__":
    k = int(input())
    a = []
    for i in range(4):
        a.append("".join([x for x in input()]))

    line = "".join(a)

    symbols_count = {}
    for number in range(1, 10):
        symbols_count[number] = line.count(str(number))

    result = 0
    for value in symbols_count.values():
        if value != 0 and value <= k * 2:
            result += 1

    print(result)
